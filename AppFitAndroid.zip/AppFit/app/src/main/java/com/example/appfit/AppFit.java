/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.example.appfit;

/**
 *
 * @author alumno
 */
public class AppFit {

    public static void main(String[] args) {
    
        AppControlador controlador = new AppControlador();
    }
    
}
